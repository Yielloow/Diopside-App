// types.ts
export type RootStackParamList = {
    SignIn: undefined;
    Home: undefined;
  };
  